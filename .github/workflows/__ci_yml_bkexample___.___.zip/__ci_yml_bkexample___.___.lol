name: ci

permissions:
  contents: read
  packages: write

on:
  push:
    branches: ["main"]
  pull_request: {}


jobs:
  backend:
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: backend
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install deps
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt

      - name: Build
        run: python -m compileall app

  # 🐳 Docker build job
  docker-build:
    runs-on: ubuntu-latest
    needs: [backend]
    steps:
      - uses: actions/checkout@v4
      - uses: docker/setup-buildx-action@v3

      # ✅ Преобразуем имя репозитория в строчные буквы
      - name: Set lowercase repository name
        id: repo_name
        shell: bash
        run: |
          REPO_LOWER=$(echo "${GITHUB_REPOSITORY}" | tr '[:upper:]' '[:lower:]')
          echo "REPO_LOWER=$REPO_LOWER" >> "$GITHUB_OUTPUT"

      - name: Docker Login to GitHub Container Registry
        uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Build and Push Images to GHCR
        env:
          REPO_LOWER: ${{ steps.repo_name.outputs.REPO_LOWER }}
        run: |
          echo "Building and pushing images for: ghcr.io/$REPO_LOWER"
          docker build -t ghcr.io/$REPO_LOWER/hom-backend:main ./backend
          docker build -t ghcr.io/$REPO_LOWER/hom-frontend:main ./frontend

          docker push ghcr.io/$REPO_LOWER/hom-backend:main
          docker push ghcr.io/$REPO_LOWER/hom-frontend:main


  # 🚀 Deploy job
  deploy:
    runs-on: ubuntu-latest
    needs: [docker-build]
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v4
      
      - name: Define deployment environment variables
        id: deploy_env
        shell: bash
        run: |
          REPO_LOWER=$(echo "${GITHUB_REPOSITORY}" | tr '[:upper:]' '[:lower:]')
          echo "REPO_LOWER=$REPO_LOWER" >> "$GITHUB_OUTPUT"
          echo "DB_URL_STAGE=${{ secrets.DB_URL_STAGE }}" >> "$GITHUB_OUTPUT"
          echo "JWT_SECRET_STAGE=${{ secrets.JWT_SECRET_STAGE }}" >> "$GITHUB_OUTPUT"
          echo "CORS_ORIGINS_STAGE=${{ secrets.CORS_ORIGINS_STAGE }}" >> "$GITHUB_OUTPUT"
          echo "REMOTE_HOST=${{ secrets.REMOTE_HOST }}" >> "$GITHUB_OUTPUT"

      - name: Deploy to DigitalOcean Droplet via SSH
        uses: appleboy/ssh-action@v1.0.3
        env:
          REPO_LOWER: ${{ steps.deploy_env.outputs.REPO_LOWER }}
          DB_URL_STAGE: ${{ steps.deploy_env.outputs.DB_URL_STAGE }}
          JWT_SECRET_STAGE: ${{ steps.deploy_env.outputs.JWT_SECRET_STAGE }}
          CORS_ORIGINS_STAGE: ${{ steps.deploy_env.outputs.CORS_ORIGINS_STAGE }}
          REMOTE_HOST: ${{ steps.deploy_env.outputs.REMOTE_HOST }}
        with:
          host: ${{ steps.deploy_env.outputs.REMOTE_HOST }}
          username: deployer
          key: ${{ secrets.SSH_PRIVATE_KEY }}
          envs: REPO_LOWER,DB_URL_STAGE,JWT_SECRET_STAGE,CORS_ORIGINS_STAGE,REMOTE_HOST
          script: |
            set -e 
            DEPLOY_DIR="/var/www/hom_mvp/stage"
            
            # 1. EXPORT VARIABLES NEEDED FOR DOCKER COMPOSE PULL
            # This is the CRITICAL FIX: we define and export image variables explicitly to the shell environment.
            export IMAGE_REPO="ghcr.io/${REPO_LOWER}"
            export BACKEND_IMAGE="${IMAGE_REPO}/hom-backend:main"
            export FRONTEND_IMAGE="${IMAGE_REPO}/hom-frontend:main"

            echo ">>> Creating stage.env on remote server..."
            mkdir -p "${DEPLOY_DIR}"
            cd "${DEPLOY_DIR}"

            # 2. Create stage.env (contains secrets for containers via env_file)
            cat <<EOF > stage.env
            DB_URL=${DB_URL_STAGE}
            JWT_SECRET=${JWT_SECRET_STAGE}
            CORS_ORIGINS=${CORS_ORIGINS_STAGE}
            APP_ENV=staging
            JWT_EXPIRE_MIN=60
            VITE_API_URL=http://${REMOTE_HOST}:8000
            REDIS_URL=redis://redis:6379 
            EOF

            echo ">>> Deploying docker-compose.stage.yml..."
            
            # 3. Pull and Up. Docker Compose will now use the exported variables 
            # (BACKEND_IMAGE, FRONTEND_IMAGE) for the image names.
            docker compose -f docker-compose.stage.yml pull
            docker compose -f docker-compose.stage.yml up -d --force-recreate

            echo "✅ Deployment to Droplet finished successfully."